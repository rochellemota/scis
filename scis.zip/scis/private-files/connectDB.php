<?php
//MYSQL DATABASE 

//CHANGE 'localhost' 'root' to your server name and username of your database. After the username add ,'password' as password of your database 
$db = mysqli_connect('sql203.epizy.com', 'epiz_32019445','mL8WblOwOX', 'epiz_32019445_scis') or
	die('Unable to Connect to mySQL');


	mysqli_select_db($db, 'scis') or die(mysql_error($db));
?>
