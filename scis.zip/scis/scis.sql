-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 23, 2022 at 10:52 AM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scis`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_table`
--

DROP TABLE IF EXISTS `account_table`;
CREATE TABLE IF NOT EXISTS `account_table` (
  `Account_username` varchar(20) NOT NULL,
  `Account_password` varchar(100) DEFAULT NULL,
  `Account_type` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`Account_username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account_table`
--

INSERT INTO `account_table` (`Account_username`, `Account_password`, `Account_type`) VALUES
('admin', 'c8837b23ff8aaa8a2dde915473ce0991', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `family_member`
--

DROP TABLE IF EXISTS `family_member`;
CREATE TABLE IF NOT EXISTS `family_member` (
  `SC_IDNO` int(10) DEFAULT NULL,
  `SC_DEPNAME` varchar(50) DEFAULT NULL,
  `SC_DEPOCCUPATION` varchar(50) DEFAULT NULL,
  KEY `SC_IDNO` (`SC_IDNO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family_member`
--

INSERT INTO `family_member` (`SC_IDNO`, `SC_DEPNAME`, `SC_DEPOCCUPATION`) VALUES
(146422, 'Benjie Gaspar', 'Student'),
(146422, 'Nicole Gaspar', 'Student'),
(146422, 'Melvin Dimaano', 'Stall Owner'),
(416322, 'Nino Lalata', 'Farmer'),
(416322, 'Micah Lalata', 'PWD'),
(416322, '', ''),
(10492, '', ''),
(10492, '', ''),
(10492, '', ''),
(68221, '', ''),
(68221, '', ''),
(68221, '', ''),
(46321, '', ''),
(46321, '', ''),
(46321, '', ''),
(143822, 'Aiza Soretes', 'Pharmacy Assistant'),
(143822, '', ''),
(143822, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
CREATE TABLE IF NOT EXISTS `logs` (
  `DATE` datetime NOT NULL,
  `ACTION` varchar(50) NOT NULL,
  `USERNAME` varchar(50) NOT NULL,
  `LOG_INFO` varchar(100) NOT NULL,
  PRIMARY KEY (`DATE`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`DATE`, `ACTION`, `USERNAME`, `LOG_INFO`) VALUES
('2022-06-20 10:05:36', 'Added user', 'admin', 'Application 0146422'),
('2022-06-20 10:08:33', 'Added user', 'admin', 'Application 0416322'),
('2022-06-20 10:13:15', 'Added user', 'admin', 'Application 10492'),
('2022-06-20 10:15:48', 'Added user', 'admin', 'Application 0068221'),
('2022-06-20 10:25:27', 'Added user', 'admin', 'Application 0046321'),
('2022-06-20 10:29:00', 'Added user', 'admin', 'Application 0143822');

-- --------------------------------------------------------

--
-- Table structure for table `sr_citizen_table`
--

DROP TABLE IF EXISTS `sr_citizen_table`;
CREATE TABLE IF NOT EXISTS `sr_citizen_table` (
  `APP_TYPE` varchar(10) DEFAULT NULL,
  `SC_TELNUM` varchar(15) DEFAULT NULL,
  `SC_YRSOFRES` int(11) DEFAULT NULL,
  `SC_GENDER` varchar(10) DEFAULT NULL,
  `SC_CIVILSTATUS` varchar(15) DEFAULT NULL,
  `SC_EDUCATTAIN` varchar(30) DEFAULT NULL,
  `SC_LNAME` varchar(60) DEFAULT NULL,
  `SC_FNAME` varchar(60) DEFAULT NULL,
  `SC_MNAME` varchar(60) DEFAULT NULL,
  `SC_STREET` varchar(60) DEFAULT NULL,
  `SC_BARANGAY` varchar(60) DEFAULT NULL,
  `SC_CITY` varchar(60) DEFAULT NULL,
  `SC_BDAY` date DEFAULT NULL,
  `SC_BPLACE` varchar(60) DEFAULT NULL,
  `SC_NAMESPOUSE` varchar(60) DEFAULT NULL,
  `SC_AGESPOUSE` int(150) DEFAULT NULL,
  `SC_AGE` int(150) DEFAULT NULL,
  `SC_EMPLOYMENT` varchar(60) DEFAULT NULL,
  `SC_POSITION` varchar(60) DEFAULT NULL,
  `SC_WORKADDR` varchar(60) DEFAULT NULL,
  `SC_OTHERINCOME` varchar(60) DEFAULT NULL,
  `SC_SALARY` float DEFAULT NULL,
  `SC_EMPLOYER` varchar(60) DEFAULT NULL,
  `SC_WORKTEL` varchar(60) DEFAULT NULL,
  `SC_OTHERINCOMEAMT` float DEFAULT NULL,
  `SC_PHILHEALTHMEM` varchar(10) DEFAULT NULL,
  `SC_PHILHEALTHNO` int(20) DEFAULT NULL,
  `SC_PHILHEALTHDEP` varchar(10) DEFAULT NULL,
  `SC_PHILHEALTHDEPNO` int(20) DEFAULT NULL,
  `SC_IDNO` int(11) NOT NULL,
  PRIMARY KEY (`SC_IDNO`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sr_citizen_table`
--

INSERT INTO `sr_citizen_table` (`APP_TYPE`, `SC_TELNUM`, `SC_YRSOFRES`, `SC_GENDER`, `SC_CIVILSTATUS`, `SC_EDUCATTAIN`, `SC_LNAME`, `SC_FNAME`, `SC_MNAME`, `SC_STREET`, `SC_BARANGAY`, `SC_CITY`, `SC_BDAY`, `SC_BPLACE`, `SC_NAMESPOUSE`, `SC_AGESPOUSE`, `SC_AGE`, `SC_EMPLOYMENT`, `SC_POSITION`, `SC_WORKADDR`, `SC_OTHERINCOME`, `SC_SALARY`, `SC_EMPLOYER`, `SC_WORKTEL`, `SC_OTHERINCOMEAMT`, `SC_PHILHEALTHMEM`, `SC_PHILHEALTHNO`, `SC_PHILHEALTHDEP`, `SC_PHILHEALTHDEPNO`, `SC_IDNO`) VALUES
('1', '0', 63, 'male', 'Married', 'Elementary Graduate', 'Duaso ', 'Zosimo ', 'Oriel', 'N/A ', 'Pakyas', 'Victoria Oriental Mindoro', '1958-10-23', 'Pakyas, Victoria, Or. Min.', 'Lourdes Duaso', 58, NULL, 'No', 'None', 'None', 'Rice Field', 0, 'None', '0', 2000, 'Yes', 0, 'No', 0, 10492),
('1', '0', 66, 'female', 'Married', 'College Graduate', 'Naz ', 'Analita ', 'Canvel', 'N/A ', 'Alcate', 'Victoria Oriental Mindoro', '1955-02-07', 'Lobo, Batangas', 'Jacinto Naz', 68, NULL, 'Yes', 'Midwife', 'Alcate', 'None', 0, 'None', '0', 0, 'No', 0, 'No', 0, 46321),
('1', '0', 61, 'male', 'Married', 'Elementary Graduate', 'Lorella ', 'Pio ', 'Lastrilla', 'N/A ', 'San Isidro', 'Victoria Oriental Mindoro', '1961-10-02', 'Camarines Sur', 'Nieves Lorella', 57, NULL, 'No', 'None', 'None', 'None', 0, 'None', '0', 0, 'No', 0, 'No', 0, 68221),
('1', '0', 64, 'female', 'Married', 'Elementary Graduate', 'Bueno ', 'Marites ', 'Cabral', 'N/A ', 'Babangonan', 'Victoria Oriental Mindoro', '1957-06-21', 'Naujan, Or. Min.', 'Norberto Beuno', 57, NULL, 'No', 'None', 'None', 'None', 0, 'None', '0', 0, 'No', 0, 'No', 0, 143822),
('1', '0', 60, 'male', 'Married', 'Highschool Graduate', 'Dimaano ', 'Benito ', 'Roxas', 'N/A ', 'Poblacion III', 'Victoria Oriental Mindoro', '1962-12-01', 'Poblacion I, Victoria, Or. Min.', 'None', -1, NULL, 'No', 'None', 'None', 'Store', 0, 'None', '0', 2000, 'No', 0, 'No', 0, 146422),
('1', '0', 62, 'male', 'Married', 'Elementary Undergraduate', 'Lalata ', 'Jeremias ', 'Elumbra', 'N/A ', 'San Narciso', 'Victoria Oriental Mindoro', '1959-08-08', 'Alcala, Pangasinan', 'Leonarda Lalata', 62, NULL, 'No', 'None', 'None', 'Farmer', 0, 'None', '0', 2000, 'No', 0, 'No', 0, 416322),
(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 201200000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
