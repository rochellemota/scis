<form method="post" action="chulalongkorn.php">
	<button type="submit">Submit</button>
</form>