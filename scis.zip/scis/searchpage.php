<?php include "header.php";?>
<!-- This is the search pane being transferred to a separate search page. Same mechanics follows.  -->
<div id="header_subpage1" class="col-xs-12 col-lg-12 col-md-12" text-align="center>
			<div id="header-label" class="themebg yey col-xs-10 col-md-4 col-lg-4" >
				<h1>Search Application </h1>

											
			</div>
			
			
</div>

<div class="col-lg-12 col-md-12 col-xs-12 bgblack">
<div class="col-lg-4 well">
    		<div class="panel panel-default">
    			<h4 align="center">Search By:</h4>
    			<button class="btn btn-info" onclick="showform('#search_oscaid2')">OSCA ID Number</button>
    			<button class="btn btn-info" onclick="showform('#search_name2')">Name</button>
    			<button class="btn btn-info" onclick="showform('#search_barangay2')">Barangay</button>
    			<button class="btn btn-info" onclick="showform('#search_gender2')">Gender</button>
    		</div>

    		<form  id="search_oscaid2" role="search" method="post" >
	    		<input type="hidden" name="searchby" value="OSCA ID number"></input>
	     			<input class="form-control" type="text" placeholder="OSCA ID Number" name="itemsearch" autofocus></input>
	    		<button class="btn btn-default" type="submit">Search</button>
    		</form>
    		<form id="search_name2" role="search" method="post" action="private-files/searchresults.php">
	    		<input type="hidden" name="searchby" value="Name"></input>
	     			<input class="form-control" type="text" placeholder="Name" name="itemsearch"></input>
	    		<button class="btn btn-default" type="submit" >Search</button>
    		</form>

    		<form  id="search_barangay2" role="search" method="post" action="private-files/searchresults.php">
	    		<input type="hidden" name="searchby" value="Address"></input>
	     			<select name="itemsearch" class="form-control" required="">
						<option value="Alcate">Alcate</option>
						<option value="Antonino">Antonino</option>
						<option value="Babangonan">Babangonan</option>
						<option value="Bagong Buhay">Bagong Buhay</option>
						<option value="Bagong Silang">Bagong Silang</option>
						<option value="Bambanin">Bambanin</option>
						<option value="Bethel">Bethel</option>
						<option value="Canaan">Canaan</option>
						<option value="Concepcion">Concepcion</option>
						<option value="Duongan">Duongan</option>
						<option value="Jose Leido Jr.">Jose Leido Jr.</option>
						<option value="Loyal">Loyal</option>
						<option value="Mabini">Mabini</option>
						<option value="Macatoc">Macatoc</option>
						<option value="Malabo">Malabo</option>
						<option value="Merit">Merit</option>
						<option value="Ordovilla">Ordovilla</option>
						<option value="Malabo">Malabo</option>
						<option value="Merit">Merit</option>
						<option value="Ordovilla">Ordovilla</option>
						<option value="Pakyas">Pakyas</option>
						<option value="Poblacion I">Poblacion I</option>
						<option value="Poblacion II">Poblacion II</option>
						<option value="Poblacion III">Poblacion III</option>
						<option value="Poblacion IV">Poblacion IV</option>
						<option value="Sampaguita">Sampaguita</option>
						<option value="San Antonio">San Antonio</option>
						<option value="San Cristobal">San Cristobal</option>
						<option value="San Gabriel">San Gabriel</option>
						<option value="San Gelacio">San Gelacio</option>
						<option value="San Isidro">San Isidro</option>
						<option value="San Juan">San Juan</option>
						<option value="San Narciso">San Narciso</option>
						<option value="Urdaneta">Urdaneta</option>
						<option value="Villa Cerveza">Villa Cerveza</option>
				</select>
	    		<button class="btn btn-default" type="submit" >Search</button>
    		</form>

    		<form id="search_gender2" role="search" method="post" action="private-files/searchresults.php">
	    		<input type="hidden" name="searchby" value="Gender"></input>
	     			<select name="itemsearch" class="form-control" required="">
					<option value="Male">Male</option>
					<option value="Female">Female</option>
				</select>
	    		<button class="btn btn-default" type="submit" >Search</button>
    		</form>
        </div>
        <div class="col-lg-8">
        	<div id="results2">
        	</div>
        </div>
</div>