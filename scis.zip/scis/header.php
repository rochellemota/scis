	<?php
		session_start();
		if ($_SESSION['auth'] != 1) {
			header("Location: index.php?errcode=2"); 
		}
		// If the user has not yet logged in, go to login page
	?>
	<!DOCTYPE html>
	<html>
		<head>
			<!-- Call external scripts -->
			<?include "private-files/connectDB.php";?>
			<script src="custom_scripts/jquery-2.1.1.js"></script>
			<link type="text/css" rel="stylesheet" href="bootstrap/css/bootstrap.min.css"/>
			<link type="text/css" rel="stylesheet" href="custom_scripts/styler.css"/>
			<script src="bootstrap/js/bootstrap.min.js"></script>
			<script src="custom_scripts/scis.js"></script>
			<script type="text/javascript" src="http://ajax.microsoft.com/ajax/jquery.validate/1.7/jquery.validate.min.js"></script>

			<meta name="viewport" content="width=device-width, initial-scale=1">
		</head>
		<body>
			<!-- Navbar  -->
			<nav class="navbar navbar-default" role="navigation">
				<div class="container">
					

					<div  class="navbar-default text-center">
					<img class="mr-5" src="img/logo.jpeg" alt="" height="100px" width="100px"/>
					<h3>PEDERASYON NG MGA NAKATATANDA NG VICTORIA, INC (PMNV)</h3>
					<h5>Municipality of Victoria 5205</h5>
				</div>
			</div>
					</div>
				</div>
		<div class="container-fluid">
			<!-- Menu button -->
			
			<div class="navbar-default navbar-left mt-3">
					<button id="menubtn" class="btn btn-success">
					<span class="glyphicon glyphicon-align-justify"></span>
					MENU
					</button>
				</div>
				
				<!-- Logo -->
				

				<!-- Search button -->
				<div class="navbar-default navbar-right">
					<button id="searchbtn" class="btn btn-success">
					<span class="glyphicon glyphicon-search"></span>
				
					</button>
				</div>


		</div><!-- /.container-fluid -->
		</nav>
	
		<!-- Menu buttons -->
		<body id="login">
		<div id="menu-navigate" class="col-lg-2 themebg menu-template">
		
			<a href="home.php" class="whitetext"><h4><span class="glyphicon glyphicon-home"></span> &nbsp; Home</h4></a>
			</hr>
			<a href="form_newApplication.php" class="whitetext"><h4><span class="glyphicon glyphicon-plus"></span> &nbsp; New Application</h4></a>
			<a href="viewallapplications.php" class="whitetext"><h4><span class="glyphicon glyphicon-list"></span> &nbsp; View Applications</h4></a>
			<a href="searchpage.php" class="whitetext"><h4><span class="glyphicon glyphicon-search"></span> &nbsp; Search</h4></a>
			<a href="logout.php" class="whitetext"><h4><span class="glyphicon glyphicon-eject"></span> &nbsp; Logout</h4></a>
	       
			
			
		</div>
		
		
		<!-- Search pane -->
		<div id="search-navigate" class="col-lg-10 bgwhite menu-template">
			<div class="col-lg-4">
				<div class="panel panel-default">
					<!-- Search by buttons -->
					<h4 align="center">Search By:</h4>
					<button class="btn btn-info" onclick="showform('#search_oscaid')">OSCA ID Number</button>
					<button class="btn btn-info" onclick="showform('#search_name')">Name</button>
					<button class="btn btn-info" onclick="showform('#search_barangay')">Barangay</button>
					<button class="btn btn-info" onclick="showform('#search_gender')">Gender</button>
				</div>

				<!-- Search by OSCA ID -->
				<form  id="search_oscaid" role="search" method="post" >
					<input type="hidden" name="searchby" value="OSCA ID number"></input>
						<input class="form-control" type="text" placeholder="OSCA ID Number" name="itemsearch" autofocus></input>
					<button class="btn btn-default" type="submit">Search</button>
				</form>

				<!-- Search by name -->
				<form id="search_name" role="search" method="post" action="private-files/searchresults.php">
					<input type="hidden" name="searchby" value="Name"></input>
						<input class="form-control" type="text" placeholder="Name" name="itemsearch"></input>
					<button class="btn btn-default" type="submit" >Search</button>
				</form>

				<!-- Search by barangay -->
				<form  id="search_barangay" role="search" method="post" action="private-files/searchresults.php">
					<input type="hidden" name="searchby" value="Address"></input>
						<select name="itemsearch" class="form-control" required="">
							<option value="Alcate">Alcate</option>
							<option value="Antonino">Antonino</option>
							<option value="Babangonan">Babangonan</option>
							<option value="Bagong Buhay">Bagong Buhay</option>
							<option value="Bagong Silang">Bagong Silang</option>
							<option value="Bambanin">Bambanin</option>
							<option value="Bethel">Bethel</option>
							<option value="Canaan">Canaan</option>
							<option value="Duongan">Duongan</option>
							<option value="Jose Leido Jr">Jose Leido Jr</option>
							<option value="Loyal">Loyal</option>
							<option value="Mabini">Mabini</option>
							<option value="Macatoc">Macatoc</option>
							<option value="Malabo">Malabo</option>
							<option value="Merit">Merit</option>
							<option value="Ordovilla">Ordovilla</option>
							<option value="Pakyas">Pakyas</option>
							<option value="Poblacion I">Poblacion I</option>
							<option value="Poblacion II">Poblacion II</option>
							<option value="Poblacion III">Poblacion III</option>
							<option value="Poblacion IV">Poblacion IV</option>
							<option value="Sampaguita">Sampaguita</option>
							<option value="San Antonio">San Antonio</option>
							<option value="San Cristobal">San Cristobal</option>
							<option value="San Gabriel">SAn Gabriel</option>
							<option value="San Gelacio">San Gelacio</option>
							<option value="San Isidro">San Isidro</option>
							<option value="San Juan">San Juan</option>
							<option value="San Narciso">San Narciso</option>
							<option value="Urdaneta">Urdaneta</option>
							<option value="Villa Cerveza">Villa Cerveza</option>
					</select>
					<button class="btn btn-default" type="submit" >Search</button>
				</form>


				<!-- Search by gender -->
				<form id="search_gender" role="search" method="post" action="private-files/searchresults.php">
					<input type="hidden" name="searchby" value="Gender"></input>
						<select name="itemsearch" class="form-control" required="">
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					</select>
					<button class="btn btn-default" type="submit" >Search</button>
				</form>

		
			</div>
			<!-- Output results -->
			<div class="col-lg-8">
				<div id="results">
				</div>
			</div>

			
		</div>